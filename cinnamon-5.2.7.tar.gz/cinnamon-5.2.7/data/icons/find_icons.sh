#!/bin/sh

ls -1 | grep hicolor.*\.svg
